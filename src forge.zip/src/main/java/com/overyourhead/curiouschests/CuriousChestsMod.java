package com.overyourhead.curiouschests;

import com.overyourhead.curiouschests.common.chest.bottomless.StorageChestEvents;
import com.overyourhead.curiouschests.common.chest.sentinel.SentinelEvents;
import com.overyourhead.curiouschests.common.chest.trapper.TrapperEvents;
import com.overyourhead.curiouschests.common.chest.witch.WitchChestEvents;
import com.overyourhead.curiouschests.core.*;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(CuriousChestsMod.MOD_ID)
public final class CuriousChestsMod {
    public static final String MOD_ID = "curiouschests";

    public CuriousChestsMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModCreativeTabs.TABS.register(modBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modBus);
        ModMenus.MENUS.register(modBus);
        ModParticles.PARTICLES.register(modBus);
        ModSounds.SOUNDS.register(modBus);
        ModNetworking.register();

        MinecraftForge.EVENT_BUS.addListener(SentinelEvents::onBreakSpeed);
        MinecraftForge.EVENT_BUS.addListener(SentinelEvents::onBreak);
        MinecraftForge.EVENT_BUS.addListener(StorageChestEvents::onRightClickBlock);
        MinecraftForge.EVENT_BUS.addListener(WitchChestEvents::onRightClickBlock);
        MinecraftForge.EVENT_BUS.addListener(TrapperEvents::onBreak);
    }
}
