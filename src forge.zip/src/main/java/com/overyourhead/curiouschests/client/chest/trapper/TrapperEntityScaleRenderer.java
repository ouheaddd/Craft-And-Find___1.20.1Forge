package com.overyourhead.curiouschests.client.chest.trapper;

import com.overyourhead.curiouschests.CuriousChestsMod;
import com.overyourhead.curiouschests.common.chest.trapper.TrapperChestRuntime;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayDeque;
import java.util.Deque;

/** Backports the 1.21 generic SCALE-attribute suction visual to Forge 1.20.1. */
@Mod.EventBusSubscriber(modid = CuriousChestsMod.MOD_ID, value = Dist.CLIENT)
public final class TrapperEntityScaleRenderer {
    private static final ThreadLocal<Deque<Boolean>> SCALED = ThreadLocal.withInitial(ArrayDeque::new);

    private TrapperEntityScaleRenderer() {}

    @SubscribeEvent
    public static void pre(RenderLivingEvent.Pre<?, ?> event) {
        float scale = TrapperChestRuntime.clientCaptureScale(event.getEntity().getUUID());
        boolean apply = scale < 0.999F;
        SCALED.get().push(apply);
        if (apply) {
            event.getPoseStack().pushPose();
            event.getPoseStack().scale(scale, scale, scale);
        }
    }

    @SubscribeEvent
    public static void post(RenderLivingEvent.Post<?, ?> event) {
        Deque<Boolean> stack = SCALED.get();
        if (!stack.isEmpty() && stack.pop()) event.getPoseStack().popPose();
    }
}
