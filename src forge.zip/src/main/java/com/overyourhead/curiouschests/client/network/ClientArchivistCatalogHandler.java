package com.overyourhead.curiouschests.client.network;

import com.overyourhead.curiouschests.client.gui.ArchivistBookViewScreen;
import com.overyourhead.curiouschests.common.network.ArchivistCatalogPayload;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.screens.inventory.BookViewScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.*;

public final class ClientArchivistCatalogHandler {
    private static final int BOOK_TEXT_WIDTH = 114;
    private static final int MAX_TEXT_LINES = 13;
    private ClientArchivistCatalogHandler() {}

    public static void handle(ArchivistCatalogPayload payload) {
        Minecraft minecraft = Minecraft.getInstance();
        List<DisplayEntry> entries = new ArrayList<>();
        for (ArchivistCatalogPayload.Entry entry : payload.entries()) {
            Enchantment enchantment = ForgeRegistries.ENCHANTMENTS.getValue(entry.enchantmentId());
            if (enchantment == null) continue;
            entries.add(new DisplayEntry(enchantment, entry.level(), entry.count(), enchantment.getFullname(entry.level()).getString().toLowerCase(Locale.ROOT), entry.enchantmentId().toString()));
        }
        entries.sort(Comparator.comparingInt(DisplayEntry::count).reversed().thenComparing(DisplayEntry::sortName).thenComparingInt(DisplayEntry::level).thenComparing(DisplayEntry::id));
        List<Component> pages = buildPages(minecraft.font, entries);
        BookViewScreen.BookAccess access = new BookViewScreen.BookAccess() {
            @Override
            public int getPageCount() {
                return pages.size();
            }

            @Override
            public FormattedText getPageRaw(int page) {
                return page >= 0 && page < pages.size() ? pages.get(page) : FormattedText.EMPTY;
            }
        };
        if (entries.isEmpty()) minecraft.setScreen(new ArchivistBookViewScreen(access, Component.translatable("gui.curiouschests.archivist.catalog_empty").withStyle(ChatFormatting.BLACK)));
        else minecraft.setScreen(new BookViewScreen(access));
    }

    private static List<Component> buildPages(Font font, List<DisplayEntry> entries) {
        if (entries.isEmpty()) return List.of(Component.translatable("gui.curiouschests.archivist.catalog_title").withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.BOLD));
        List<Component> pages = new ArrayList<>(); Component page=Component.empty(); int usedLines=0; boolean hasEntry=false;
        page=page.copy().append(Component.translatable("gui.curiouschests.archivist.catalog_title").withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.BOLD)).append("\n\n"); usedLines=2;
        for(DisplayEntry entry:entries){ Component line=Component.empty().append(entry.enchantment().getFullname(entry.level())).append(Component.literal("  ×"+entry.count()).withStyle(ChatFormatting.BLACK)); int lc=Math.max(1,font.split(line,BOOK_TEXT_WIDTH).size());
            if(usedLines>0 && usedLines+lc>MAX_TEXT_LINES){ pages.add(page); page=Component.empty(); usedLines=0; hasEntry=false; }
            if(hasEntry) page=page.copy().append("\n"); page=page.copy().append(line); usedLines+=lc; hasEntry=true; }
        if(!page.getString().isEmpty()) pages.add(page); return pages.isEmpty()?List.of(Component.empty()):pages;
    }
    private record DisplayEntry(Enchantment enchantment, int level, int count, String sortName, String id) {}
}
