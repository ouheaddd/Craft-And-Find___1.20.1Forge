package com.overyourhead.curiouschests.client.network;
import com.overyourhead.curiouschests.client.gui.SpecialChestScreen;
import com.overyourhead.curiouschests.common.network.SentinelLogPayload;
import net.minecraft.client.Minecraft;
public final class ClientSentinelLogHandler { private ClientSentinelLogHandler() {} public static void handle(SentinelLogPayload payload){ if(Minecraft.getInstance().screen instanceof SpecialChestScreen screen) screen.applySentinelLog(payload); } }
