package com.overyourhead.curiouschests.client.network;
import com.overyourhead.curiouschests.client.gui.SpecialChestScreen;
import com.overyourhead.curiouschests.common.network.TrapperContentsPayload;
import net.minecraft.client.Minecraft;
public final class ClientTrapperContentsHandler { private ClientTrapperContentsHandler() {} public static void handle(TrapperContentsPayload payload){ Minecraft mc=Minecraft.getInstance(); if(mc.screen instanceof SpecialChestScreen screen) screen.applyTrapperContents(payload); } }
