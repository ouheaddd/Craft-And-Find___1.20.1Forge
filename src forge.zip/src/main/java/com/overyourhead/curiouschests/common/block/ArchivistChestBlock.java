package com.overyourhead.curiouschests.common.block;

import com.overyourhead.curiouschests.common.chest.ChestKind;

public final class ArchivistChestBlock extends AbstractSpecialChestBlock {
    public ArchivistChestBlock(Properties properties) { super(properties); }
    @Override public ChestKind kind() { return ChestKind.ARCHIVIST; }
}
