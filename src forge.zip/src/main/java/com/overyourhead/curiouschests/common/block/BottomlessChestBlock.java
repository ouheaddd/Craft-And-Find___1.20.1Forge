package com.overyourhead.curiouschests.common.block;

import com.overyourhead.curiouschests.common.chest.ChestKind;

public final class BottomlessChestBlock extends AbstractSpecialChestBlock {
    public BottomlessChestBlock(Properties properties) { super(properties); }
    @Override public ChestKind kind() { return ChestKind.BOTTOMLESS; }
}
