package com.overyourhead.curiouschests.common.block;

import com.overyourhead.curiouschests.common.chest.ChestKind;

public final class BuildersChestBlock extends AbstractSpecialChestBlock {
    public BuildersChestBlock(Properties properties) { super(properties); }
    @Override public ChestKind kind() { return ChestKind.BUILDERS; }
}
