package com.overyourhead.curiouschests.common.block;

import com.overyourhead.curiouschests.common.chest.ChestKind;

public final class CollectorsChestBlock extends AbstractSpecialChestBlock {
    public CollectorsChestBlock(Properties properties) { super(properties); }
    @Override public ChestKind kind() { return ChestKind.COLLECTORS; }
}
