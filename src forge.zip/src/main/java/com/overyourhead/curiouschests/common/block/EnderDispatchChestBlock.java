package com.overyourhead.curiouschests.common.block;

import com.overyourhead.curiouschests.common.chest.ChestKind;

public final class EnderDispatchChestBlock extends AbstractSpecialChestBlock {
    public EnderDispatchChestBlock(Properties properties) { super(properties); }
    @Override public ChestKind kind() { return ChestKind.ENDER_DISPATCH; }
}
