package com.overyourhead.curiouschests.common.block;

import com.overyourhead.curiouschests.common.chest.ChestKind;

public final class InfernalChestBlock extends AbstractSpecialChestBlock {
    public InfernalChestBlock(Properties properties) { super(properties); }
    @Override public ChestKind kind() { return ChestKind.INFERNAL; }
}
