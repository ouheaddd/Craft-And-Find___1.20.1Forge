package com.overyourhead.curiouschests.common.block;

import com.overyourhead.curiouschests.common.chest.ChestKind;

public final class ResonantChestBlock extends AbstractSpecialChestBlock {
    public ResonantChestBlock(Properties properties) { super(properties); }
    @Override public ChestKind kind() { return ChestKind.RESONANT; }
}
