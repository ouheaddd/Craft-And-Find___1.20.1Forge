package com.overyourhead.curiouschests.common.block;
import com.overyourhead.curiouschests.common.blockentity.SpecialChestBlockEntity;
import com.overyourhead.curiouschests.common.chest.ChestKind;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
public final class SculkSentinelChestBlock extends AbstractSpecialChestBlock {
    public SculkSentinelChestBlock(Properties properties){super(properties);} @Override public ChestKind kind(){return ChestKind.SCULK_SENTINEL;}
    @Override public boolean isSignalSource(BlockState state){return true;}
    @Override public int getSignal(BlockState state, BlockGetter level, BlockPos pos, Direction direction){ BlockEntity be=level.getBlockEntity(pos); return be instanceof SpecialChestBlockEntity chest && chest.isSentinelAlarmActive()?15:0; }
    @Override public int getDirectSignal(BlockState state, BlockGetter level, BlockPos pos, Direction direction){return getSignal(state,level,pos,direction);}
}
