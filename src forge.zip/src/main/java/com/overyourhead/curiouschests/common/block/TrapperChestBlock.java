package com.overyourhead.curiouschests.common.block;

import com.overyourhead.curiouschests.common.blockentity.SpecialChestBlockEntity;
import com.overyourhead.curiouschests.common.chest.ChestKind;
import com.overyourhead.curiouschests.core.ModParticles;
import com.overyourhead.curiouschests.core.ModSounds;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;

import java.util.List;

public final class TrapperChestBlock extends AbstractSpecialChestBlock {
    public static final BooleanProperty OCCUPIED=BlockStateProperties.OCCUPIED;
    public TrapperChestBlock(Properties properties){super(properties);registerDefaultState(defaultBlockState().setValue(OCCUPIED,false));}
    @Override public ChestKind kind(){return ChestKind.TRAPPER;}
    @Override protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder){super.createBlockStateDefinition(builder);builder.add(OCCUPIED);}

    @Override
    public List<ItemStack> getDrops(BlockState state, LootParams.Builder builder) {
        var blockEntity = builder.getOptionalParameter(LootContextParams.BLOCK_ENTITY);
        var breaker = builder.getOptionalParameter(LootContextParams.THIS_ENTITY);
        if (blockEntity instanceof SpecialChestBlockEntity chest && breaker instanceof Player player
                && player.isShiftKeyDown() && chest.isTrapperPackOnBreak()) {
            ItemStack packed = chest.createPackedTrapperStack();
            if (!packed.isEmpty()) {
                if (player.level() instanceof ServerLevel level) {
                    level.playSound(null, chest.getBlockPos(), ModSounds.VAULT_CLOSE_SHUTTER.get(), SoundSource.BLOCKS, 0.72F, 0.92F);
                    double cx=chest.getBlockPos().getX()+0.5D, cy=chest.getBlockPos().getY()+0.65D, cz=chest.getBlockPos().getZ()+0.5D;
                    level.sendParticles(ModParticles.TRAPPER_LINK.get(), cx,cy,cz,14,0.42D,0.38D,0.42D,0.08D);
                }
                return List.of(packed);
            }
        }
        return super.getDrops(state,builder);
    }
}
