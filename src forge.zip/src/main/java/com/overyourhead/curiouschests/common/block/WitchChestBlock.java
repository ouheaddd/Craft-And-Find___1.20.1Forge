package com.overyourhead.curiouschests.common.block;

import com.overyourhead.curiouschests.common.chest.ChestKind;

public final class WitchChestBlock extends AbstractSpecialChestBlock {
    public WitchChestBlock(Properties properties) { super(properties); }
    @Override public ChestKind kind() { return ChestKind.WITCH; }
}
