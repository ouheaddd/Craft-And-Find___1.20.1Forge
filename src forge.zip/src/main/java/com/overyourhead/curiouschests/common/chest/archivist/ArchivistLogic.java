package com.overyourhead.curiouschests.common.chest.archivist;

import com.overyourhead.curiouschests.common.blockentity.SpecialChestBlockEntity;
import com.overyourhead.curiouschests.common.network.ArchivistCatalogPayload;
import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.EnchantedBookItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.EnchantmentInstance;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.*;

public final class ArchivistLogic {
    public static final int STORAGE_SLOTS = 54;
    public static final int INPUT_SLOT = 54;
    public static final int MAX_BOOKS_PER_ENTRY = 64;
    public static final int PROCESS_INTERVAL_TICKS = 10;
    private ArchivistLogic() {}

    public static List<ArchivistCatalogPayload.Entry> collectCatalog(SpecialChestBlockEntity chest) {
        Map<CatalogKey, Integer> counts = new LinkedHashMap<>();
        for (int slot = 0; slot < STORAGE_SLOTS; slot++) {
            ItemStack stack = chest.getItem(slot);
            if (!isProcessableBook(stack)) continue;
            for (var entry : EnchantmentHelper.getEnchantments(stack).entrySet()) {
                ResourceLocation id = ForgeRegistries.ENCHANTMENTS.getKey(entry.getKey());
                if (id != null) counts.merge(new CatalogKey(id, entry.getValue()), stack.getCount(), Integer::sum);
            }
        }
        List<ArchivistCatalogPayload.Entry> entries = new ArrayList<>(counts.size());
        counts.forEach((key, count) -> entries.add(new ArchivistCatalogPayload.Entry(key.enchantmentId(), key.level(), count)));
        return entries;
    }

    public static boolean isProcessableBook(ItemStack stack) {
        return stack.is(Items.ENCHANTED_BOOK) && !EnchantmentHelper.getEnchantments(stack).isEmpty();
    }
    public static boolean isStorableBook(ItemStack stack) { return stack.is(Items.BOOK) || isProcessableBook(stack); }

    public static boolean processOne(ServerLevel level, BlockPos pos, SpecialChestBlockEntity chest) {
        ItemStack input = chest.getItem(INPUT_SLOT);
        if (!isProcessableBook(input)) return false;
        Map<Enchantment, Integer> enchantments = EnchantmentHelper.getEnchantments(input);
        List<ItemStack> separatedBooks = new ArrayList<>(enchantments.size());
        enchantments.forEach((enchantment, lvl) -> separatedBooks.add(singleEnchantmentBook(enchantment, lvl)));
        if (separatedBooks.isEmpty()) return false;

        NonNullList<ItemStack> simulated = NonNullList.withSize(STORAGE_SLOTS, ItemStack.EMPTY);
        for (int slot = 0; slot < STORAGE_SLOTS; slot++) simulated.set(slot, chest.getItem(slot).copy());
        for (ItemStack book : separatedBooks) if (!insertOne(simulated, book)) return false;
        for (int slot = 0; slot < STORAGE_SLOTS; slot++) chest.setItem(slot, simulated.get(slot));
        chest.removeItem(INPUT_SLOT, 1);
        chest.setChanged();
        level.playSound(null, pos, SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.BLOCKS, 0.55F, 1.15F);
        level.sendParticles(ParticleTypes.ENCHANT, pos.getX()+0.5D, pos.getY()+1.0D, pos.getZ()+0.5D,
                Math.min(18, 5 + separatedBooks.size()*3), 0.35D, 0.25D, 0.35D, 0.02D);
        return true;
    }

    private static ItemStack singleEnchantmentBook(Enchantment enchantment, int level) {
        return EnchantedBookItem.createForEnchantment(new EnchantmentInstance(enchantment, level));
    }

    private static boolean insertOne(NonNullList<ItemStack> storage, ItemStack offered) {
        for (int slot=0; slot<storage.size(); slot++) {
            ItemStack existing=storage.get(slot);
            if (existing.isEmpty() || !ItemStack.isSameItemSameTags(existing, offered) || existing.getCount() >= MAX_BOOKS_PER_ENTRY) continue;
            existing.grow(1); return true;
        }
        for (int slot=0; slot<storage.size(); slot++) if (storage.get(slot).isEmpty()) { storage.set(slot, offered.copyWithCount(1)); return true; }
        return false;
    }
    private record CatalogKey(ResourceLocation enchantmentId, int level) {}
}
