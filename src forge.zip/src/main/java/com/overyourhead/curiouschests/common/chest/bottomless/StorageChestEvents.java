package com.overyourhead.curiouschests.common.chest.bottomless;

import com.overyourhead.curiouschests.common.block.BottomlessChestBlock;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.Event;

public final class StorageChestEvents {
    private StorageChestEvents() {}
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (!event.getEntity().isShiftKeyDown()) return;
        var state = event.getLevel().getBlockState(event.getPos());
        if (!(state.getBlock() instanceof BottomlessChestBlock)) return;
        if (event.getFace() != state.getValue(BottomlessChestBlock.FACING)) return;
        event.setUseBlock(Event.Result.ALLOW);
        event.setUseItem(Event.Result.DENY);
    }
}
