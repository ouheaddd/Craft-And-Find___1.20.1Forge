package com.overyourhead.curiouschests.common.chest.trapper;

import com.overyourhead.curiouschests.common.block.TrapperChestBlock;
import com.overyourhead.curiouschests.common.blockentity.SpecialChestBlockEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.level.BlockEvent;

/** Arms the packed-drop path when a Trapper is mined while sneaking. */
public final class TrapperEvents {
    private TrapperEvents() {}
    public static void onBreak(BlockEvent.BreakEvent event) {
        if (!(event.getState().getBlock() instanceof TrapperChestBlock)) return;
        Player player=event.getPlayer();
        if(!player.isShiftKeyDown()) return;
        if(!(event.getLevel() instanceof ServerLevel level)) return;
        if(!(level.getBlockEntity(event.getPos()) instanceof SpecialChestBlockEntity chest)) return;
        chest.armTrapperPackBreak(level);
    }
}
