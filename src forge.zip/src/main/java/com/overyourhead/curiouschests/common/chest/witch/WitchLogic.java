package com.overyourhead.curiouschests.common.chest.witch;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ArrowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.item.alchemy.PotionUtils;

import java.util.List;

public final class WitchLogic {
    public static final int STORAGE_SLOTS = 54;
    public static final int MAX_POTIONS_PER_SLOT = 16;
    private WitchLogic() {}

    public static boolean isPotionStack(ItemStack stack) {
        if (stack.isEmpty() || stack.getItem() instanceof ArrowItem) return false;
        return stack.is(Items.POTION) || stack.is(Items.SPLASH_POTION) || stack.is(Items.LINGERING_POTION)
                || (stack.hasTag() && stack.getTag().contains("Potion"));
    }
    public static boolean isSupported(ItemStack stack) { return isPotionStack(stack) || stack.is(Items.GLASS_BOTTLE) || stack.is(Items.DRAGON_BREATH); }
    public static int maxPerSlot(ItemStack stack) { return isPotionStack(stack) ? MAX_POTIONS_PER_SLOT : stack.getMaxStackSize(); }

    public static ItemStack randomVanillaPotion(RandomSource random) {
        List<Potion> vanilla = BuiltInRegistries.POTION.stream().filter(potion -> {
            ResourceLocation id = BuiltInRegistries.POTION.getKey(potion);
            return id != null && "minecraft".equals(id.getNamespace());
        }).toList();
        if (vanilla.isEmpty()) return ItemStack.EMPTY;
        return PotionUtils.setPotion(new ItemStack(Items.POTION), vanilla.get(random.nextInt(vanilla.size())));
    }
}
