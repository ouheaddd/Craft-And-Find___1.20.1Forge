package com.overyourhead.curiouschests.common.item;

import com.overyourhead.curiouschests.common.chest.resonant.ResonanceNames;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.UUID;

public final class ResonanceCrystalItem extends Item {
    private static final String RESONANCE_ID_TAG = "ResonanceId";

    public ResonanceCrystalItem(Properties properties) { super(properties.stacksTo(16)); }

    public static UUID getTarget(ItemStack stack) {
        return stack.hasTag() && stack.getTag().hasUUID(RESONANCE_ID_TAG) ? stack.getTag().getUUID(RESONANCE_ID_TAG) : null;
    }

    public static boolean isAttuned(ItemStack stack) { return getTarget(stack) != null; }
    public static void attune(ItemStack stack, UUID nodeId) { stack.getOrCreateTag().putUUID(RESONANCE_ID_TAG, nodeId); }

    @Override public Component getName(ItemStack stack) {
        return Component.translatable(isAttuned(stack) ? "item.curiouschests.resonance_crystal.attuned" : "item.curiouschests.resonance_crystal.dormant");
    }

    @Override public boolean isFoil(ItemStack stack) { return isAttuned(stack) || super.isFoil(stack); }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        UUID target = getTarget(stack);
        if (target == null) tooltip.add(Component.translatable("tooltip.curiouschests.resonance_crystal.dormant").withStyle(ChatFormatting.GRAY));
        else tooltip.add(Component.translatable("tooltip.curiouschests.resonance_crystal.attuned", ResonanceNames.forNode(target)).withStyle(ChatFormatting.LIGHT_PURPLE));
        super.appendHoverText(stack, level, tooltip, flag);
    }
}
