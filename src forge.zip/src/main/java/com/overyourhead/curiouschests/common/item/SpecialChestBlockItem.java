package com.overyourhead.curiouschests.common.item;

import com.overyourhead.curiouschests.client.render.SpecialChestItemExtensions;
import com.overyourhead.curiouschests.common.blockentity.SpecialChestBlockEntity;
import com.overyourhead.curiouschests.common.chest.ChestKind;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Consumer;

public final class SpecialChestBlockItem extends BlockItem {
    private final ChestKind kind;
    public SpecialChestBlockItem(Block block, ChestKind kind, Item.Properties properties) { super(block, properties); this.kind = kind; }
    public ChestKind kind() { return kind; }

    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) { consumer.accept(new SpecialChestItemExtensions()); }

    @Override
    public int getMaxStackSize(ItemStack stack) {
        if (kind == ChestKind.TRAPPER && SpecialChestBlockEntity.getPackedTrapperEntityCount(stack) > 0) {
            return 1;
        }
        return super.getMaxStackSize(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        String prefix = "tooltip.curiouschests." + kind.id();
        tooltip.add(Component.translatable(prefix + ".lore_1").withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC));
        tooltip.add(Component.translatable(prefix + ".lore_2").withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC));
        tooltip.add(Component.empty());
        tooltip.add(Component.translatable(prefix + ".ability").withStyle(ChatFormatting.GRAY));
        if (kind == ChestKind.BOTTOMLESS) tooltip.add(Component.translatable(prefix + ".display_hint").withStyle(ChatFormatting.GRAY));
        if (kind == ChestKind.COLLECTORS) tooltip.add(Component.translatable(prefix + ".output").withStyle(ChatFormatting.GRAY));
        if (kind == ChestKind.SCULK_SENTINEL) tooltip.add(Component.translatable(prefix + ".defense").withStyle(ChatFormatting.GRAY));
        if (kind == ChestKind.INFERNAL) tooltip.add(Component.translatable(prefix + ".warning").withStyle(ChatFormatting.RED));
        if (kind == ChestKind.RESONANT) tooltip.add(Component.translatable(prefix + ".rebind_hint").withStyle(ChatFormatting.DARK_PURPLE));
        if (kind == ChestKind.WITCH) tooltip.add(Component.translatable(prefix + ".brew_hint").withStyle(ChatFormatting.DARK_PURPLE));
        if (kind == ChestKind.ARCHIVIST) tooltip.add(Component.translatable(prefix + ".catalog_hint").withStyle(ChatFormatting.DARK_PURPLE));
        if (kind == ChestKind.TRAPPER) {
            int captured = SpecialChestBlockEntity.getPackedTrapperEntityCount(stack);
            tooltip.add(Component.translatable(prefix + ".captured", captured).withStyle(captured > 0 ? ChatFormatting.AQUA : ChatFormatting.GRAY));
            tooltip.add(Component.translatable(prefix + ".pack_hint").withStyle(ChatFormatting.DARK_AQUA));
        }
        super.appendHoverText(stack, level, tooltip, flag);
    }
}
