package com.overyourhead.curiouschests.common.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import java.util.*;

public record ArchivistCatalogPayload(List<Entry> entries) {
    private static final int MAX_ENTRIES = 256;
    private static final int MAX_ID_LENGTH = 128;
    public ArchivistCatalogPayload { entries = List.copyOf(entries.subList(0, Math.min(MAX_ENTRIES, entries.size()))); }
    public static void encode(ArchivistCatalogPayload msg, FriendlyByteBuf buffer) {
        buffer.writeVarInt(msg.entries.size());
        for (Entry entry : msg.entries) { buffer.writeUtf(entry.enchantmentId().toString(), MAX_ID_LENGTH); buffer.writeVarInt(entry.level()); buffer.writeVarInt(entry.count()); }
    }
    public static ArchivistCatalogPayload decode(FriendlyByteBuf buffer) {
        int encodedCount = Math.max(0, buffer.readVarInt());
        List<Entry> entries = new ArrayList<>(Math.min(MAX_ENTRIES, encodedCount));
        for (int i=0;i<encodedCount;i++) {
            ResourceLocation id = new ResourceLocation(buffer.readUtf(MAX_ID_LENGTH));
            int level = Math.max(1, buffer.readVarInt()); int count = Math.max(0, buffer.readVarInt());
            if (i < MAX_ENTRIES && count > 0) entries.add(new Entry(id, level, count));
        }
        return new ArchivistCatalogPayload(entries);
    }
    public record Entry(ResourceLocation enchantmentId, int level, int count) {}
}
