package com.overyourhead.curiouschests.common.network;

import net.minecraft.network.FriendlyByteBuf;

public record ReleaseTrapperEntityPayload(int containerId, int index) {
    public static void encode(ReleaseTrapperEntityPayload msg, FriendlyByteBuf buf) { buf.writeVarInt(msg.containerId); buf.writeVarInt(msg.index); }
    public static ReleaseTrapperEntityPayload decode(FriendlyByteBuf buf) { return new ReleaseTrapperEntityPayload(buf.readVarInt(), buf.readVarInt()); }
}
