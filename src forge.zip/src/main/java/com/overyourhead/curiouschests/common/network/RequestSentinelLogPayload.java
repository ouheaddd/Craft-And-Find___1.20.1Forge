package com.overyourhead.curiouschests.common.network;

import net.minecraft.network.FriendlyByteBuf;

public record RequestSentinelLogPayload(int containerId) {
    public static void encode(RequestSentinelLogPayload msg, FriendlyByteBuf buf) { buf.writeVarInt(msg.containerId); }
    public static RequestSentinelLogPayload decode(FriendlyByteBuf buf) { return new RequestSentinelLogPayload(buf.readVarInt()); }
}
