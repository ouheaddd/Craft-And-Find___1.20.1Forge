package com.overyourhead.curiouschests.common.network;

import net.minecraft.network.FriendlyByteBuf;

public record RequestTrapperContentsPayload(int containerId) {
    public static void encode(RequestTrapperContentsPayload msg, FriendlyByteBuf buf) { buf.writeVarInt(msg.containerId); }
    public static RequestTrapperContentsPayload decode(FriendlyByteBuf buf) { return new RequestTrapperContentsPayload(buf.readVarInt()); }
}
