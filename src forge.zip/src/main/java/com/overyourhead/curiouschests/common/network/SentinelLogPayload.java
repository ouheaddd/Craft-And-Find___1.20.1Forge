package com.overyourhead.curiouschests.common.network;

import com.overyourhead.curiouschests.common.sentinel.SentinelIntrusionType;
import com.overyourhead.curiouschests.common.sentinel.SentinelLogEntry;
import net.minecraft.network.FriendlyByteBuf;
import java.util.*;

public record SentinelLogPayload(int containerId, long serverGameTime, List<SentinelLogEntry> entries) {
    private static final int MAX_ENTRIES = 5;
    private static final int MAX_NAME_LENGTH = 64;
    public SentinelLogPayload { entries = List.copyOf(entries.subList(0, Math.min(MAX_ENTRIES, entries.size()))); }
    public static void encode(SentinelLogPayload msg, FriendlyByteBuf buffer) {
        buffer.writeVarInt(msg.containerId); buffer.writeVarLong(msg.serverGameTime); buffer.writeVarInt(msg.entries.size());
        for (SentinelLogEntry e : msg.entries) { buffer.writeUUID(e.playerId()); buffer.writeUtf(e.playerName(), MAX_NAME_LENGTH); buffer.writeByte(e.action().ordinal()); buffer.writeVarLong(e.gameTime()); buffer.writeVarInt(e.attempts()); }
    }
    public static SentinelLogPayload decode(FriendlyByteBuf buffer) {
        int containerId=buffer.readVarInt(); long time=buffer.readVarLong(); int n=Math.max(0,buffer.readVarInt());
        List<SentinelLogEntry> entries=new ArrayList<>(Math.min(MAX_ENTRIES,n));
        for(int i=0;i<n;i++) { SentinelLogEntry e=new SentinelLogEntry(buffer.readUUID(),buffer.readUtf(MAX_NAME_LENGTH),SentinelIntrusionType.byId(buffer.readUnsignedByte()),buffer.readVarLong(),Math.max(1,buffer.readVarInt())); if(i<MAX_ENTRIES) entries.add(e); }
        return new SentinelLogPayload(containerId,time,entries);
    }
}
