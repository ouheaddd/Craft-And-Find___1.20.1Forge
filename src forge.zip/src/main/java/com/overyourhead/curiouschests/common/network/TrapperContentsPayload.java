package com.overyourhead.curiouschests.common.network;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import java.util.*;

public record TrapperContentsPayload(int containerId, List<CompoundTag> entities) {
    private static final int MAX_ENTITIES = 9;
    public TrapperContentsPayload {
        List<CompoundTag> safe=new ArrayList<>(); for(int i=0;i<Math.min(MAX_ENTITIES,entities.size());i++) safe.add(entities.get(i).copy()); entities=List.copyOf(safe);
    }
    public static void encode(TrapperContentsPayload msg, FriendlyByteBuf buffer) {
        buffer.writeVarInt(msg.containerId); buffer.writeVarInt(msg.entities.size()); for(CompoundTag tag:msg.entities) buffer.writeNbt(tag);
    }
    public static TrapperContentsPayload decode(FriendlyByteBuf buffer) {
        int containerId=buffer.readVarInt(); int n=Math.max(0,buffer.readVarInt()); List<CompoundTag> entities=new ArrayList<>(Math.min(MAX_ENTITIES,n));
        for(int i=0;i<n;i++){ CompoundTag tag=buffer.readNbt(); if(i<MAX_ENTITIES && tag!=null) entities.add(tag); } return new TrapperContentsPayload(containerId,entities);
    }
}
