package com.overyourhead.curiouschests.core;

import com.overyourhead.curiouschests.CuriousChestsMod;
import com.overyourhead.curiouschests.common.blockentity.SpecialChestBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, CuriousChestsMod.MOD_ID);
    public static final RegistryObject<BlockEntityType<SpecialChestBlockEntity>> SPECIAL_CHEST = BLOCK_ENTITIES.register("special_chest", () -> BlockEntityType.Builder.of(
            SpecialChestBlockEntity::new,
            ModBlocks.BOTTOMLESS_CHEST.get(), ModBlocks.INFERNAL_CHEST.get(), ModBlocks.ENDER_DISPATCH_CHEST.get(),
            ModBlocks.BUILDERS_CHEST.get(), ModBlocks.COLLECTORS_CHEST.get(), ModBlocks.SCULK_SENTINEL_CHEST.get(),
            ModBlocks.RESONANT_CHEST.get(), ModBlocks.ARCHIVISTS_CHEST.get(), ModBlocks.WITCHS_CHEST.get(), ModBlocks.TRAPPERS_CHEST.get()
    ).build(null));
    private ModBlockEntities() {}
}
