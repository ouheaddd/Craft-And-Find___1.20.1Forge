package com.overyourhead.curiouschests.core;

import com.overyourhead.curiouschests.CuriousChestsMod;
import com.overyourhead.curiouschests.common.block.*;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.PushReaction;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, CuriousChestsMod.MOD_ID);

    private static BlockBehaviour.Properties props() {
        return BlockBehaviour.Properties.copy(Blocks.CHEST).noOcclusion();
    }

    private static BlockBehaviour.Properties sentinelProps() {
        return BlockBehaviour.Properties.copy(Blocks.CHEST).noOcclusion().strength(4.0F, 1200.0F).pushReaction(PushReaction.BLOCK);
    }

    public static final RegistryObject<BottomlessChestBlock> BOTTOMLESS_CHEST = BLOCKS.register("bottomless_chest", () -> new BottomlessChestBlock(props().sound(SoundType.WOOD)));
    public static final RegistryObject<InfernalChestBlock> INFERNAL_CHEST = BLOCKS.register("infernal_chest", () -> new InfernalChestBlock(props().sound(SoundType.NETHER_BRICKS).lightLevel(state -> 5)));
    public static final RegistryObject<EnderDispatchChestBlock> ENDER_DISPATCH_CHEST = BLOCKS.register("ender_dispatch_chest", () -> new EnderDispatchChestBlock(props().sound(SoundType.STONE)));
    public static final RegistryObject<BuildersChestBlock> BUILDERS_CHEST = BLOCKS.register("builders_chest", () -> new BuildersChestBlock(props()));
    public static final RegistryObject<CollectorsChestBlock> COLLECTORS_CHEST = BLOCKS.register("collectors_chest", () -> new CollectorsChestBlock(props()));
    public static final RegistryObject<SculkSentinelChestBlock> SCULK_SENTINEL_CHEST = BLOCKS.register("sculk_sentinel_chest", () -> new SculkSentinelChestBlock(sentinelProps().sound(SoundType.SCULK_CATALYST)));
    public static final RegistryObject<ResonantChestBlock> RESONANT_CHEST = BLOCKS.register("resonant_chest", () -> new ResonantChestBlock(props().sound(SoundType.AMETHYST).lightLevel(state -> 5)));
    public static final RegistryObject<ArchivistChestBlock> ARCHIVISTS_CHEST = BLOCKS.register("archivists_chest", () -> new ArchivistChestBlock(props()));
    public static final RegistryObject<WitchChestBlock> WITCHS_CHEST = BLOCKS.register("witchs_chest", () -> new WitchChestBlock(props().lightLevel(state -> 6)));
    public static final RegistryObject<TrapperChestBlock> TRAPPERS_CHEST = BLOCKS.register("trappers_chest", () -> new TrapperChestBlock(
            BlockBehaviour.Properties.copy(Blocks.CHEST).noOcclusion().strength(2.5F, 2.5F)
                    .lightLevel(state -> state.hasProperty(TrapperChestBlock.OCCUPIED) && state.getValue(TrapperChestBlock.OCCUPIED) ? 4 : 0)
    ));

    private ModBlocks() {}
}
