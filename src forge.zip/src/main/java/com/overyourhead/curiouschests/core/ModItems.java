package com.overyourhead.curiouschests.core;

import com.overyourhead.curiouschests.CuriousChestsMod;
import com.overyourhead.curiouschests.common.chest.ChestKind;
import com.overyourhead.curiouschests.common.item.ResonanceCrystalItem;
import com.overyourhead.curiouschests.common.item.SpecialChestBlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, CuriousChestsMod.MOD_ID);

    private static RegistryObject<SpecialChestBlockItem> chest(String id, RegistryObject<? extends net.minecraft.world.level.block.Block> block, ChestKind kind, boolean fireproof) {
        return ITEMS.register(id, () -> {
            Item.Properties props = new Item.Properties();
            if (fireproof) props.fireResistant();
            return new SpecialChestBlockItem(block.get(), kind, props);
        });
    }

    public static final RegistryObject<SpecialChestBlockItem> BOTTOMLESS_CHEST_ITEM = chest("bottomless_chest", ModBlocks.BOTTOMLESS_CHEST, ChestKind.BOTTOMLESS, false);
    public static final RegistryObject<SpecialChestBlockItem> INFERNAL_CHEST_ITEM = chest("infernal_chest", ModBlocks.INFERNAL_CHEST, ChestKind.INFERNAL, true);
    public static final RegistryObject<SpecialChestBlockItem> ENDER_DISPATCH_CHEST_ITEM = chest("ender_dispatch_chest", ModBlocks.ENDER_DISPATCH_CHEST, ChestKind.ENDER_DISPATCH, false);
    public static final RegistryObject<SpecialChestBlockItem> BUILDERS_CHEST_ITEM = chest("builders_chest", ModBlocks.BUILDERS_CHEST, ChestKind.BUILDERS, false);
    public static final RegistryObject<SpecialChestBlockItem> COLLECTORS_CHEST_ITEM = chest("collectors_chest", ModBlocks.COLLECTORS_CHEST, ChestKind.COLLECTORS, false);
    public static final RegistryObject<SpecialChestBlockItem> SCULK_SENTINEL_CHEST_ITEM = chest("sculk_sentinel_chest", ModBlocks.SCULK_SENTINEL_CHEST, ChestKind.SCULK_SENTINEL, false);
    public static final RegistryObject<SpecialChestBlockItem> RESONANT_CHEST_ITEM = chest("resonant_chest", ModBlocks.RESONANT_CHEST, ChestKind.RESONANT, false);
    public static final RegistryObject<SpecialChestBlockItem> ARCHIVISTS_CHEST_ITEM = chest("archivists_chest", ModBlocks.ARCHIVISTS_CHEST, ChestKind.ARCHIVIST, false);
    public static final RegistryObject<SpecialChestBlockItem> WITCHS_CHEST_ITEM = chest("witchs_chest", ModBlocks.WITCHS_CHEST, ChestKind.WITCH, false);
    public static final RegistryObject<SpecialChestBlockItem> TRAPPERS_CHEST_ITEM = chest("trappers_chest", ModBlocks.TRAPPERS_CHEST, ChestKind.TRAPPER, false);
    public static final RegistryObject<ResonanceCrystalItem> RESONANCE_CRYSTAL = ITEMS.register("resonance_crystal", () -> new ResonanceCrystalItem(new Item.Properties()));

    private ModItems() {}
}
