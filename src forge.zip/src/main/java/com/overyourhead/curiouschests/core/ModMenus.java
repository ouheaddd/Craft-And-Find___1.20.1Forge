package com.overyourhead.curiouschests.core;

import com.overyourhead.curiouschests.CuriousChestsMod;
import com.overyourhead.curiouschests.common.chest.ChestKind;
import com.overyourhead.curiouschests.common.menu.SpecialChestMenu;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModMenus {
    public static final DeferredRegister<MenuType<?>> MENUS = DeferredRegister.create(ForgeRegistries.MENU_TYPES, CuriousChestsMod.MOD_ID);
    public static final RegistryObject<MenuType<SpecialChestMenu>> BOTTOMLESS = register("bottomless", ChestKind.BOTTOMLESS);
    public static final RegistryObject<MenuType<SpecialChestMenu>> INFERNAL = register("infernal", ChestKind.INFERNAL);
    public static final RegistryObject<MenuType<SpecialChestMenu>> ENDER_DISPATCH = register("ender_dispatch", ChestKind.ENDER_DISPATCH);
    public static final RegistryObject<MenuType<SpecialChestMenu>> BUILDERS = register("builders", ChestKind.BUILDERS);
    public static final RegistryObject<MenuType<SpecialChestMenu>> COLLECTORS = register("collectors", ChestKind.COLLECTORS);
    public static final RegistryObject<MenuType<SpecialChestMenu>> SCULK_SENTINEL = register("sculk_sentinel", ChestKind.SCULK_SENTINEL);
    public static final RegistryObject<MenuType<SpecialChestMenu>> RESONANT = register("resonant", ChestKind.RESONANT);
    public static final RegistryObject<MenuType<SpecialChestMenu>> ARCHIVIST = register("archivist", ChestKind.ARCHIVIST);
    public static final RegistryObject<MenuType<SpecialChestMenu>> WITCH = register("witch", ChestKind.WITCH);
    public static final RegistryObject<MenuType<SpecialChestMenu>> TRAPPER = register("trapper", ChestKind.TRAPPER);

    private static RegistryObject<MenuType<SpecialChestMenu>> register(String id, ChestKind kind) {
        return MENUS.register(id, () -> new MenuType<>((containerId, inv) -> SpecialChestMenu.client(forKind(kind), containerId, inv, kind), FeatureFlags.DEFAULT_FLAGS));
    }

    public static MenuType<SpecialChestMenu> forKind(ChestKind kind) {
        return switch (kind) {
            case BOTTOMLESS -> BOTTOMLESS.get(); case INFERNAL -> INFERNAL.get(); case ENDER_DISPATCH -> ENDER_DISPATCH.get();
            case BUILDERS -> BUILDERS.get(); case COLLECTORS -> COLLECTORS.get(); case SCULK_SENTINEL -> SCULK_SENTINEL.get();
            case RESONANT -> RESONANT.get(); case ARCHIVIST -> ARCHIVIST.get(); case WITCH -> WITCH.get(); case TRAPPER -> TRAPPER.get();
        };
    }
    private ModMenus() {}
}
