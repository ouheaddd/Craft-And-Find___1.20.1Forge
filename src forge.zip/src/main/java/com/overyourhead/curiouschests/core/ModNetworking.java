package com.overyourhead.curiouschests.core;

import com.overyourhead.curiouschests.CuriousChestsMod;
import com.overyourhead.curiouschests.client.network.*;
import com.overyourhead.curiouschests.common.blockentity.SpecialChestBlockEntity;
import com.overyourhead.curiouschests.common.chest.ChestKind;
import com.overyourhead.curiouschests.common.menu.SpecialChestMenu;
import com.overyourhead.curiouschests.common.network.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.function.Supplier;

public final class ModNetworking {
    private static final String PROTOCOL = "3";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(CuriousChestsMod.MOD_ID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);
    private static int id;
    private ModNetworking() {}

    public static void register() {
        CHANNEL.messageBuilder(RequestSentinelLogPayload.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(RequestSentinelLogPayload::encode).decoder(RequestSentinelLogPayload::decode).consumerMainThread(ModNetworking::handleSentinelLogRequest).add();
        CHANNEL.messageBuilder(SentinelLogPayload.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(SentinelLogPayload::encode).decoder(SentinelLogPayload::decode).consumerMainThread((msg,ctx)->{ ClientSentinelLogHandler.handle(msg); ctx.get().setPacketHandled(true); }).add();
        CHANNEL.messageBuilder(ArchivistCatalogPayload.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(ArchivistCatalogPayload::encode).decoder(ArchivistCatalogPayload::decode).consumerMainThread((msg,ctx)->{ ClientArchivistCatalogHandler.handle(msg); ctx.get().setPacketHandled(true); }).add();
        CHANNEL.messageBuilder(RequestTrapperContentsPayload.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(RequestTrapperContentsPayload::encode).decoder(RequestTrapperContentsPayload::decode).consumerMainThread(ModNetworking::handleTrapperContentsRequest).add();
        CHANNEL.messageBuilder(ReleaseTrapperEntityPayload.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(ReleaseTrapperEntityPayload::encode).decoder(ReleaseTrapperEntityPayload::decode).consumerMainThread(ModNetworking::handleTrapperRelease).add();
        CHANNEL.messageBuilder(TrapperContentsPayload.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(TrapperContentsPayload::encode).decoder(TrapperContentsPayload::decode).consumerMainThread((msg,ctx)->{ ClientTrapperContentsHandler.handle(msg); ctx.get().setPacketHandled(true); }).add();
    }

    public static void sendToServer(Object message) { CHANNEL.sendToServer(message); }
    public static void sendToPlayer(ServerPlayer player, Object message) { CHANNEL.sendTo(message, player.connection.connection, NetworkDirection.PLAY_TO_CLIENT); }

    private static void handleTrapperContentsRequest(RequestTrapperContentsPayload msg, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context ctx=supplier.get(); ServerPlayer player=ctx.getSender();
        if(player!=null && player.containerMenu instanceof SpecialChestMenu menu && menu.containerId==msg.containerId() && menu.kind()==ChestKind.TRAPPER) {
            SpecialChestBlockEntity chest=menu.blockEntity(); if(chest!=null) sendTrapperContents(player,menu,chest);
        } ctx.setPacketHandled(true);
    }
    private static void handleTrapperRelease(ReleaseTrapperEntityPayload msg, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context ctx=supplier.get(); ServerPlayer player=ctx.getSender();
        if(player!=null && player.containerMenu instanceof SpecialChestMenu menu && menu.containerId==msg.containerId() && menu.kind()==ChestKind.TRAPPER) {
            SpecialChestBlockEntity chest=menu.blockEntity(); if(chest!=null && chest.releaseTrappedEntity(player.serverLevel(),msg.index())) sendTrapperContents(player,menu,chest);
        } ctx.setPacketHandled(true);
    }
    private static void sendTrapperContents(ServerPlayer player, SpecialChestMenu menu, SpecialChestBlockEntity chest) {
        sendToPlayer(player,new TrapperContentsPayload(menu.containerId,chest.getTrappedEntityTags()));
    }
    private static void handleSentinelLogRequest(RequestSentinelLogPayload msg, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context ctx=supplier.get(); ServerPlayer player=ctx.getSender();
        if(player!=null && player.containerMenu instanceof SpecialChestMenu menu && menu.containerId==msg.containerId() && menu.kind()==ChestKind.SCULK_SENTINEL) {
            SpecialChestBlockEntity chest=menu.blockEntity(); if(chest!=null && chest.canSentinelAccess(player)) sendToPlayer(player,new SentinelLogPayload(menu.containerId,player.serverLevel().getGameTime(),chest.getSentinelLogEntries()));
        } ctx.setPacketHandled(true);
    }
}
