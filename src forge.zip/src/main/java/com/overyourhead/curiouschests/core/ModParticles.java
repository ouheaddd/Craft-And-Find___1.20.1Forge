package com.overyourhead.curiouschests.core;

import com.overyourhead.curiouschests.CuriousChestsMod;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModParticles {
    public static final DeferredRegister<ParticleType<?>> PARTICLES = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, CuriousChestsMod.MOD_ID);
    public static final RegistryObject<SimpleParticleType> WITCH_STEAM = PARTICLES.register("witch_steam", () -> new SimpleParticleType(false));
    public static final RegistryObject<SimpleParticleType> WITCH_SPARK = PARTICLES.register("witch_spark", () -> new SimpleParticleType(false));
    public static final RegistryObject<SimpleParticleType> WITCH_BURST = PARTICLES.register("witch_burst", () -> new SimpleParticleType(false));
    public static final RegistryObject<SimpleParticleType> TRAPPER_LINK = PARTICLES.register("trapper_link", () -> new SimpleParticleType(false));
    public static final RegistryObject<SimpleParticleType> TRAPPER_ORBIT = PARTICLES.register("trapper_orbit", () -> new SimpleParticleType(false));
    private ModParticles() {}
}
