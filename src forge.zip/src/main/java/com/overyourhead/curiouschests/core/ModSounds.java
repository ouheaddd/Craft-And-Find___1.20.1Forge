package com.overyourhead.curiouschests.core;

import com.overyourhead.curiouschests.CuriousChestsMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, CuriousChestsMod.MOD_ID);

    public static final RegistryObject<SoundEvent> VAULT_OPEN_SHUTTER = register("block.vault.open_shutter");
    public static final RegistryObject<SoundEvent> VAULT_CLOSE_SHUTTER = register("block.vault.close_shutter");
    public static final RegistryObject<SoundEvent> VAULT_ACTIVATE = register("block.vault.activate");
    public static final RegistryObject<SoundEvent> VAULT_AMBIENT = register("block.vault.ambient");
    public static final RegistryObject<SoundEvent> VAULT_INSERT_ITEM = register("block.vault.insert_item");
    public static final RegistryObject<SoundEvent> VAULT_EJECT_ITEM = register("block.vault.eject_item");

    private static RegistryObject<SoundEvent> register(String name) {
        ResourceLocation id = new ResourceLocation(CuriousChestsMod.MOD_ID, name);
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(id));
    }
    private ModSounds() {}
}
