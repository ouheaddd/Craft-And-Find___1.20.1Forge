Place the six Vault .ogg files here using these names:
open_shutter.ogg
close_shutter.ogg
activate.ogg
ambient.ogg
insert_item.ogg
eject_item.ogg

The Forge 1.20.1 port registers them as curiouschests:block.vault.* so they do not collide with other backports.
